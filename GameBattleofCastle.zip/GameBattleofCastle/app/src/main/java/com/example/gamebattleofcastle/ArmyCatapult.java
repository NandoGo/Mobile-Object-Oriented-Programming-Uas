package com.example.gamebattleofcastle;

public class ArmyCatapult extends Army
{

    public ArmyCatapult(int powerArmy)
    {
        super(powerArmy);
        this.TypeOFArmy=this.catapult;
    }



}
