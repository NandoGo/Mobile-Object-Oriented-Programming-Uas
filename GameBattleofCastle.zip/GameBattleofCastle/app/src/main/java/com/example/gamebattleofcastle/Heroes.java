package com.example.gamebattleofcastle;

public class Heroes {
    double boost=0.40;
    String heroName;

    public double getBoost()
    {
        return boost;
    }
    public void setBoost(double boost)
    {
        this.boost = boost;
    }
    public String getHeroName()
    {
        return heroName;
    }
    public void setHeroName(String heroName)
    {
        this.heroName = heroName;
    }
    public Heroes(String heroName)
    {
        super();
        this.heroName = heroName;
    }





}
