package com.example.gamebattleofcastle;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class Main extends AppCompatActivity
{

    public Main()
    {
        BattleTo();
    }




    private void BattleTo()
    {
        Vector<Heroes>vhero= new Vector<Heroes>();
        Vector<Heroes>vheroenemy = new Vector<Heroes>();

        Vector<Army>varmy = new Vector<Army>();
        Vector<Army>varmyenemy = new Vector<Army>();

        int survivor,enemysurvivor;

        Random random = new Random();
        int Mode = random.nextInt(2);
        if (Mode==0)
        {
            //Archer vs Cavalry
            vhero.add(new Heroes("archer"));
            vhero.add(new Heroes("archer"));
            vhero.add(new Heroes("archer"));
            vhero.add(new Heroes("archer"));
            vhero.add(new Heroes("archer"));

            varmy.add(new ArmyArcher(100000));
            Castle archer = new Wood(varmy, vhero);

            vheroenemy.add(new Heroes("cavalry"));
            vheroenemy.add(new Heroes("cavalry"));
            vheroenemy.add(new Heroes("cavalry"));
            vheroenemy.add(new Heroes("cavalry"));
            vheroenemy.add(new Heroes("cavalry"));

            varmy.add(new ArmyCavalry(100000));
            Castle cavalry = new Horse(varmyenemy, vheroenemy);

            survivor=(int) (100000- (int)archer.getPower()*0.1);
            enemysurvivor=(int) (10000-(int)cavalry.getPower()*0.4);


            if (survivor<=0)
            {
                survivor=0;
            }
            if (enemysurvivor<=0)
            {
                enemysurvivor=0;
            }
            if (survivor>enemysurvivor)
            {
                System.out.println("Player 1 (ARCHER) WIN");
            } else {
                System.out.println("Player 2 (CAVALRY) WIN");

            }
        }else
            {
            //Mix Armies vs Infantry
            vhero.add(new Heroes("catapult"));
            vhero.add(new Heroes("archer"));
            vhero.add(new Heroes("infantry"));
            vhero.add(new Heroes("catapult"));
            vhero.add(new Heroes("archer"));

            varmy.add(new ArmyArcher(25000));
            varmy.add(new ArmyCatapult(25000));
            varmy.add(new ArmyCavalry(25000));
            varmy.add(new ArmyInfantry(25000));
            Castle archer = new Stone(varmy, vhero);

            vheroenemy.add(new Heroes("infantry"));
            vheroenemy.add(new Heroes("infantry"));
            vheroenemy.add(new Heroes("infatry"));
            vheroenemy.add(new Heroes("infantry"));
            vheroenemy.add(new Heroes("infantry"));

            varmy.add(new ArmyInfantry(100000));
            Castle cavalry = new Horse(varmyenemy, vheroenemy);

            survivor=(int) (100000- (int)archer.getPower()*0.3);
            enemysurvivor=(int) (10000-(int)cavalry.getPower()*0.2);


            if (survivor<=0)
            {
                survivor=0;
            }
            {
                enemysurvivor=0;
            }
            if (survivor>enemysurvivor)
            {
                System.out.println("Player 1 (MIX ARMIES) WIN");
            } else {
                System.out.println("Player 2 (INFANTRY) WIN");

            }
        }
    }


    protected void onCreate(Bundle State) {
        super.onCreate(State);
        setContentView(R.layout.activity_main);
        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                battle();
            }
        });

        public static void main (String[]Object args;){
            new Main();

        }

    }}
