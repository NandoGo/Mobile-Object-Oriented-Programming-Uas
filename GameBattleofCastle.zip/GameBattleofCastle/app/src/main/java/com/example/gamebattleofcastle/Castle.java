package com.example.gamebattleofcastle;

import java.util.Vector;

public abstract class Castle
{

    String castleName,HORSE ="horse", WOOD="wood",STEEL="steel",STONE="stone";
    Vector<Army>varmy = new Vector<>();
    Vector<Heroes>vhero = new Vector<>();
    double power=0;

    public double getPower()
    {
        return power;
    }
    public void setPower(double power)
    {
        this.power = power;
    }
    public String getCastleName() {
        return castleName;
    }
    public void setCastleName(String castleName)
    {
        this.castleName = castleName;
    }
    public Vector<Army> getVarmy()
    {
        return varmy;
    }
    public void setVarmy(Vector<Army> varmy)
    {
        this.varmy = varmy;
    }
    public Vector<Heroes> getVhero()
    {
        return vhero;
    }
    public void setVhero(Vector<Heroes> vhero)
    {
        this.vhero = vhero;
    }


    public abstract int castlePower(Vector<Heroes>vhero, Vector<Army>varmy);
    public Castle( Vector<Army> varmy, Vector<Heroes> vhero)
    {
        super();
        this.varmy = varmy;
        this.vhero = vhero;

    }






}