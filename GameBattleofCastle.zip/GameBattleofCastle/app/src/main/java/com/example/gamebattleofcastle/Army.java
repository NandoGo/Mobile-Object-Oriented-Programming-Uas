package com.example.gamebattleofcastle;


public abstract class Army
{

    String TypeOFArmy;
    int powerArmy;
    final String archer ="archer", infantry="infantry", catapult="catapult", calvary="calvary";
    public String getTypeOFArmy() {
        return TypeOFArmy;
    }
    public void setTypeOFArmy(String typeOFArmy) {
        TypeOFArmy = typeOFArmy;
    }
    public int getPowerArmy() {
        return powerArmy;
    }
    public void setPowerArmy(int powerArmy) {
        this.powerArmy = powerArmy;
    }
    public Army(int powerArmy) {
        super();
        this.powerArmy=powerArmy;
    }


}

