package com.example.gamebattleofcastle;

public class ArmyCavalry extends Army
{

    public ArmyCavalry(int powerArmy)
    {
        super(powerArmy);
        this.TypeOFArmy=this.calvary;
    }



}
