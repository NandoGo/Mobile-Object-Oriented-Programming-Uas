package com.example.gamebattleofcastle;

import java.util.Vector;

public class Horse extends Castle
{

    public Horse(Vector<Army> varmy, Vector<Heroes> vhero)
    {
        super(varmy, vhero);
        this.castleName=this.HORSE;
        this.power=castlePower(vhero, varmy);
    }

    @Override
    public int castlePower(Vector<Heroes> vhero, Vector<Army> varmy)
    {
        int power=0;
        for (int i = 0; i < varmy.size(); i++)
        {
            power+=varmy.get(i).getPowerArmy();
            if (varmy.get(i).getTypeOFArmy().equalsIgnoreCase("cavalry")) {
                power+=varmy.get(i).getPowerArmy()*0.2;

            }
        }
        for (int i = 0; i < vhero.size(); i++)
        {
            for (int j = 0; j < varmy.size(); j++)
            {
                if (vhero.get(i).getHeroName().equalsIgnoreCase(varmy.get(j).getTypeOFArmy()))
                {
                    power+=vhero.get(i).getBoost()*varmy.get(j).getPowerArmy();
                }
            }
        }
        return power;
    }


}