package com.example.gamebattleofcastle;

public class ArmyArcher extends Army
{

    public ArmyArcher(int powerArmy)
    {
        super(powerArmy);
        this.TypeOFArmy=this.archer;
    }




}

