package com.example.gamebattleofcastle;


public class ArmyInfantry extends Army
{

    public ArmyInfantry(int powerarmy)
    {
        super(powerarmy);
        this.TypeOFArmy=this.infantry;

    }
}
